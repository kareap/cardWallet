package no.cardwallet.card;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardWalletApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardWalletApplication.class, args);
    }

}
