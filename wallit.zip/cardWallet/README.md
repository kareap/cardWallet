# cardWallet

cardWallet is a digital storage tool for gift cards.

## Built with

- Spring Boot
- Maven

## Motivation

cardWallet was the authors' final project for a Java boot camp, written over a time span of 14 days.

## Authors

- kareap
- marianne-ott
- rinaal
- Iolele
